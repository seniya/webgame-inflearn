const pinkMon = {
	name: 'pink_mon',
	hpValue: 200000,
	speed: 8,
	crashDamage: 300,
	score: 3000,
	exp: 3000
}

const yellowMon = {
	name: 'yellow_mon',
	hpValue: 84000,
	speed: 10,
	crashDamage: 300,
	score: 2000,
	exp: 2000
}

const greenMon = {
	name: 'green_mon',
	hpValue: 42000,
	speed: 10,
	crashDamage: 300,
	score: 1000,
	exp: 1000
}

const greenMonBoss = {
	name: 'green_mon_boss',
	hpValue: 800000,
	speed: 4,
	crashDamage: 1000,
	score: 10000,
	exp: 10000
}

const yellowMonBoss = {
	name: 'yellow_mon_boss',
	hpValue: 1800000,
	speed: 4,
	crashDamage: 2000,
	score: 20000,
	exp: 20000
}

const pinkMonBoss = {
	name: 'pink_mon_boss',
	hpValue: 5200000,
	speed: 3,
	crashDamage: 2500,
	score: 30000,
	exp: 30000
}










