const pinkMon = {
	name: 'pink_mon',
	hpValue: 200000,
	speed: 8,
	crashDamage: 300
}

const yellowMon = {
	name: 'yellow_mon',
	hpValue: 84000,
	speed: 10,
	crashDamage: 300
}

const greenMon = {
	name: 'green_mon',
	hpValue: 44000,
	speed: 10,
	crashDamage: 300
}